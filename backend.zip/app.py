"""
A flask API that connects the UI with a KubeCTL interface allowing the user to generate and execute commands on will.
The generated commands are moderately complex and generated automatically using LLMs.
Author: Sharvini
Date: 12/11/2024
"""
import json
import torch
import shlex
import subprocess
import pickle
import re
import os
import numpy as np
from transformers import BertTokenizer, BertForSequenceClassification
from sklearn.metrics.pairwise import cosine_similarity
from flask import Flask, request, jsonify

os.environ['WANDB_DISABLED'] = 'true'

JSON_PATH = 'data-classes.json'

# Load Tokenizer, Label Encoder and Fine-Tuned Model
tokenizer = BertTokenizer.from_pretrained('models/bert/')
model = BertForSequenceClassification.from_pretrained('models/bert/')
model.eval()

# Types - Encoded Types
# Prompts - The list of all English Prompts
# Commands - The Command related to each of the English Prompts
PROMPTS, COMMANDS, TYPES = []

def load_dataset():
    prompts, commands, types = []
    with open(JSON_PATH, 'r') as f:
        data = json.load(f)

    for cmd_type, entries in data.items():
        for entry in entries:
            prompts.append(entry['prompt'])
            commands.append(entry['command'])
            types.append(cmd_type)
    
    PROMPTS = prompts
    COMMANDS = commands
    TYPES = label_encoder.transform(types)


# Load the Models relevant for Question Classifier
with open('models/question_classifier_LR.pkl', 'rb') as f:
    qc_lr = pickle.load(f)

with open('models/tfidf_vectorizer.pkl', 'rb') as f:
    tfidf_vectorizer = pickle.load(f)

with open('models/label_encoder.pkl', 'rb') as f:
    label_encoder = pickle.load(f)

app = Flask(__name__)


def question_classifier(prompt):
    """
    Params:
        prompt : str
    
    Claasify the Question into the relevant type based on the supported question types:
        * Create
        * Delete
        * Get
        * Apply
        * Describe
    """
    vectorized_prompt = tfidf_vectorizer.transform([prompt])
    predicted_type = qc_lr.predict(vectorized_prompt)[0]
    predicted_label_id = label_encoder.transform([predicted_type])[0]
    return predicted_label_id

def get_embeddings(text):
    """
    Get Embeddings for fine-grained matching within predicted command type.    
    """
    inputs = tokenizer(text, return_tensors="pt", truncation=True)
    with torch.no_grad():
        outputs = model.bert(**inputs)
    return outputs.last_hidden_state.mean(dim=1).squeeze().numpy()

def predict_command(question_type, prompt):
    """
    Params:
        question_type : str
        prompt : str
    Given the Question Type and Prompt, generate the command
    """
    relevant_prompts = [p for p, t in zip(PROMPTS, TYPES) if t == question_type]
    relevant_commands = [c for c, t in zip(COMMANDS, TYPES) if t == question_type]

    sample_embedding = get_embeddings(prompt)
    relevant_embeddings = [get_embeddings(p) for p in relevant_prompts]
    similarities = [cosine_similarity([sample_embedding], [emb]).flatten()[0] for emb in relevant_embeddings]
    best_match_index = similarities.index(max(similarities))

    return relevant_commands[best_match_index]

def fill_placeholders(command, prompt):
    """
    Params:
        command : str
        prompt : str
    Given the command and the prompt of the user, use the name from the prompt and replace it in the command.
    """
    name_match = re.search(r"named '(\w+)'", prompt)
    if name_match:
        name = name_match.group(1)
        command = command.replace('<name>', name)
        return command, name


@app.route('/generate-command', methods=['POST'])
def generate_command():
    prompt = request.json.get('prompt')
    
    if not prompt:
        return jsonify({'result': False, 'message': 'Prompt not provided'}), 400
    
    question_type = question_classifier(prompt)
    predicted_command = predict_command(question_type, prompt)
    filled_command = fill_placeholders(predicted_command, prompt)

    return jsonify({'result' : True, 'type': question_type, 'cmd' : filled_command})

@app.route('/execute-command', methods=['POST'])
def execute_command():
    command = request.json.get('command')
    if not command:
        return jsonify({'result' : False, 'message' : 'Command not provided'}), 400

    try:
        command_list = shlex.split(command)
        result = subprocess.run(command_list, text=True, capture_output=True)

        if result.returncode != 0:
            return jsonify({
                'result' : False,
                'message': 'Command execution failed',
                'stderr' : result.stderr.strip()
            }), 400
        
        return jsonify({
            'result' : True,
            'message' : 'Command executed Successfully',
            'stdout' : result.stdout.strip()
        })
    except Exception as e:
        return jsonify({'result' : False, 'message' : str(e)}), 500

if __name__ == '__main__':
    # Create the dataset and prepare the data to be used by the app
    load_dataset()
    app.run(debug=True)