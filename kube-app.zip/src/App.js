import React, { useState, useEffect } from 'react';
import axios from 'axios';
import logo from './logo.svg';
import './App.css';

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [command, setCommand] = useState("");
  const [commandResponse, setCommandResponse] = useState("");

  const executeCommand = async() => {
    if (!executeCommand.trim()) return;

    try {
      const response = await axios.post("http://127.0.0.1:5000/execute-command", {
        command: command
      });

      // TODO : Display execution status/response
    } catch(error) {
      // TODO : Display error related to command execution
    }

    setCommand("")
  }

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = { sender: "user", text: input };
    setMessages((prev) => [...prev, userMessage]);

    try {
      const response = await axios.post("http://127.0.0.1:5000/generate-command", {
        prompt: input
      });

      console.log(response)

      const botMessage = {
        sender: "bot",
        text: response.data.cmd || "Sorry, I couldn't understand that.",
      }


      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      console.log(error)
      setMessages((prev) => [
        ...prev,
        { sender: 'bot', text: 'Error: Unable to connect to Backend'},
      ]);
    }

    setInput("")
  }

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h1>Kubernetes Command Generator</h1><br />
        <p>
          Generate commands to be executed on KubeCTL based on plain English commands easing development time overall.
        </p><br />
      </header>

      <div className="chat-container">
        <div className="chat-window">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`message ${message.sender == "user" ? "user" : "bot"}`}
            >
              {message.text}
            </div>
          ))}
        </div>
        <div className="input-container">
          <input type="text" placeholder="type your message..." value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && sendMessage()}
          />
          <button onClick={sendMessage}>Send</button>
        </div>

        <div className="special-messages">
          <p className="special-message">{commandResponse}</p>
        </div>

        <div class="input-container">
          <input type="text" placeholder="Copy the command to execute..." value={command}
            onChange={(e) => setCommand(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && executeCommand()}
          />
          <button onClick={executeCommand} className="btn-green">Execute</button>
        </div>
      </div>
    </div>
  );
}

export default App;
