import logo from './logo.svg';
import './App.css';

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = { sender: "user", text: input };
    setMessages((prev) => [...prev, userMessage]);

    try {
      const response = await axios.post("http://127.0.0.1:5000/generate-command", {
        prompt: input
      });

      const botMessage = {
        sender: "bot",
        text: response.data.generated_command || "Sorry, I couldn't understand that.",
      }


      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      setMessages((prev) => [
        ...prev,
        { sender: 'bot', text: 'Error: Unable to connect to Backend'},
      ]);
    }

    setInput("")
  }

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
      </header>

      <div classNmae="chat-container">
        <div className="chat-window">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`message ${message.sender == "user" ? "user" : "bot"}`}
            >
              {message.text}
            </div>
          ))}
        </div>
        <div className="input-container">
          <input type="text" placeholder="type your message..." value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && sendMessage()}
          />
          <button onClick={sendMessage}>Send</button>
        </div>
      </div>
    </div>
  );
}

export default App;
